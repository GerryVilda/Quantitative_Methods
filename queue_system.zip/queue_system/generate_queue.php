<?php
include "db.php";

$result = $conn->query("SELECT COUNT(*) as total FROM queue");
$row = $result->fetch_assoc();

$number = $row['total'] + 1;
$queue = "Q" . str_pad($number,3,"0",STR_PAD_LEFT);

$conn->query("INSERT INTO queue(queue_number,status,arrival_time) VALUES('$queue','waiting',NOW())");

echo $queue;
?>