CREATE DATABASE IF NOT EXISTS queue_system;
USE queue_system;

CREATE TABLE IF NOT EXISTS queue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    queue_number VARCHAR(16) NOT NULL,
    status ENUM('waiting','serving','done') NOT NULL DEFAULT 'waiting',
    arrival_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    service_start DATETIME NULL,
    service_end DATETIME NULL,
    INDEX(status),
    INDEX(arrival_time)
);
