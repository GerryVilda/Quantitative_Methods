<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>How the Queue Works</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <style>
        body { background: linear-gradient(135deg, #1d7bcf 0%, #1068ba 45%, #0f5090 100%); color: #fff; }
        .glass { background: rgba(255, 255, 255, .10); backdrop-filter: blur(12px); border: 1px solid rgba(255,255,255,.18); }
        .step-card { background: rgba(255,255,255,.10); border: 1px solid rgba(255,255,255,.15); }
        .step-number { width: 3rem; height: 3rem; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-weight: 700; background: rgba(255,255,255,.18); color: #fff; }
        .btn-secondary-cust { background: rgba(255,255,255,.18); color: #fff; border: 1px solid rgba(255,255,255,.22); }
        .btn-secondary-cust:hover { background: rgba(255,255,255,.25); }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark bg-opacity-60 shadow-sm mb-4">
        <div class="container d-flex justify-content-between align-items-center">
            <a class="navbar-brand" href="index.php">Queue System</a>
            <div>
                <a class="btn btn-secondary-cust btn-sm me-2" href="index.php">Home</a>
                <a class="btn btn-warning text-dark btn-sm" href="monitor.php">Live Monitor</a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card glass shadow-lg mb-4">
                    <div class="card-body">
                        <h1 class="display-6 fw-bold">How the Queue Process Works</h1>
                        <p class="lead text-white-75">Follow the steps below to understand how students, staff, and the monitor interact with the queue system.</p>
                    </div>
                </div>

                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="card step-card p-4 shadow-sm">
                            <div class="d-flex align-items-center mb-3">
                                <div class="step-number">1</div>
                                <h5 class="mb-0 ms-3">Student Gets Ticket</h5>
                            </div>
                            <p>At the kiosk, the student taps <strong>Get Queue Number</strong>. The system creates a new waiting ticket and displays the assigned queue number.</p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card step-card p-4 shadow-sm">
                            <div class="d-flex align-items-center mb-3">
                                <div class="step-number">2</div>
                                <h5 class="mb-0 ms-3">Queue is Updated</h5>
                            </div>
                            <p>The new ticket is added to the waiting list. The system keeps track of the next tickets in line and the ticket currently being served.</p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card step-card p-4 shadow-sm">
                            <div class="d-flex align-items-center mb-3">
                                <div class="step-number">3</div>
                                <h5 class="mb-0 ms-3">Staff Calls Next</h5>
                            </div>
                            <p>The staff member presses <strong>Call Next</strong> in the staff dashboard. The system marks the next waiting ticket as <em>serving</em> and shows it on the live monitor.</p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card step-card p-4 shadow-sm">
                            <div class="d-flex align-items-center mb-3">
                                <div class="step-number">4</div>
                                <h5 class="mb-0 ms-3">Student is Served</h5>
                            </div>
                            <p>The student with the displayed queue number proceeds to the service desk. When service is complete, staff taps <strong>Finish</strong> to remove the ticket from active status.</p>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="card step-card p-4 shadow-sm">
                            <h5 class="mb-3">Roles in the Queue System</h5>
                            <ul class="list-group list-group-flush text-white-75">
                                <li class="list-group-item bg-transparent border-top-0">Student: Gets a ticket and waits until their number is called.</li>
                                <li class="list-group-item bg-transparent">Monitor: Displays the currently serving number and the next waiting tickets.</li>
                                <li class="list-group-item bg-transparent">Staff: Calls the next ticket and marks service as finished.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="text-center mt-4 text-white-50">&copy; 2026 Queue System • Easy queue management for students and staff</footer>
</body>
</html>
