<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Queue Monitor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <style>
        body { background: radial-gradient(circle at top, #0f8ac4 0%, #132140 65%, #0a1634 100%); color: #fff; }
        .big-ticket { font-size: 10rem; font-weight: 800; letter-spacing: 0.06em; transition: transform 0.25s ease; }
        .big-ticket.flash { animation: pulse 0.8s ease; }
        @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.08); } }
        .sub-ticket { font-size: 1.2rem; }
        .board { min-height: 380px; }
        .monitor-summary { font-size: 1rem; color: #d9e8ff; }
    </style>
</head>
<body>
<nav class="navbar navbar-dark bg-dark shadow-sm mb-4">
    <div class="container d-flex justify-content-between align-items-center">
        <a class="navbar-brand" href="#">Queue Monitor</a>
        <div>
            <a class="btn btn-outline-light btn-sm me-2" href="index.php">Kiosk</a>
            <a class="btn btn-warning text-dark btn-sm" href="staff.php">Staff Panel</a>
        </div>
    </div>
</nav>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="text-white">Queue Monitor</h1>
    </div>

    <div class="row g-3">
        <div class="col-lg-7">
            <div class="card p-3 board">
                <div class="card-body text-center">
                    <h3 class="text-muted sub-ticket">NOW SERVING</h3>
                    <div id="serving" class="big-ticket text-primary">---</div>
                    <p id="waitingCount" class="monitor-summary mt-3">Waiting: 0</p>
                    <p class="monitor-summary">Please proceed when your number is displayed.</p>
                </div>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card p-3 board">
                <div class="card-body">
                    <h3 class="mb-3">Next in Line</h3>
                    <ul id="nextList" class="list-group list-group-flush"></ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let lastServing = null;
async function loadQueue(){
    const res = await fetch('display_queue.php');
    const data = await res.json();

    const servingEl = document.getElementById('serving');
    if (data.serving && data.serving !== lastServing) {
        servingEl.classList.add('flash');
        setTimeout(() => servingEl.classList.remove('flash'), 800);
        lastServing = data.serving;
    }

    document.getElementById('serving').innerText = data.serving || '---';
    document.getElementById('waitingCount').innerText = `Waiting: ${data.waiting || 0}`;
    const nextList = document.getElementById('nextList');
    nextList.innerHTML = '';

    const queue = data.next.length ? data.next : [{ queue_number: 'No waiting' }];
    queue.slice(0,6).forEach((ticket,index) => {
        nextList.innerHTML += `<li class="list-group-item fs-5">${index+1}. ${ticket.queue_number}</li>`;
    });
}

loadQueue();
setInterval(loadQueue, 2000);
</script>
</body>
</html>