<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>How the Queue System Works</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #eef2f8; }
        .step-card { border-left: 5px solid #0d6efd; margin-bottom: 1rem; }
        .step-number { font-size: 2rem; font-weight: bold; color: #0d6efd; }
        .flow-arrow { text-align: center; font-size: 2rem; color: #6c757d; margin: 1rem 0; opacity: 0; animation: fadeIn 0.5s ease-in forwards; }
        .flow-arrow:nth-of-type(1) { animation-delay: 0.3s; }
        .flow-arrow:nth-of-type(2) { animation-delay: 0.8s; }
        .flow-arrow:nth-of-type(3) { animation-delay: 1.3s; }
        .flow-arrow:nth-of-type(4) { animation-delay: 1.8s; }
        .animate-flow { animation: slideInLeft 0.8s ease-out forwards; opacity: 0; }
        .animate-flow:nth-child(1) { animation-delay: 0s; }
        .animate-flow:nth-child(2) { animation-delay: 0.5s; }
        .animate-flow:nth-child(3) { animation-delay: 1s; }
        .animate-flow:nth-child(4) { animation-delay: 1.5s; }
        .animate-flow:nth-child(5) { animation-delay: 2s; }
        @keyframes slideInLeft {
            0% { opacity: 0; transform: translateX(-50px) rotate(-5deg); }
            50% { opacity: 0.5; transform: translateX(-10px) rotate(1deg); }
            100% { opacity: 1; transform: translateX(0) rotate(0deg); }
        }
        .animation-container { display: flex; justify-content: center; align-items: center; flex-wrap: wrap; gap: 1rem; margin: 2rem 0; padding: 1.5rem; background: #ffffff; border-radius: 32px; box-shadow: 0 18px 45px rgba(15, 23, 42, 0.08); }
        .flow-step { display: flex; flex-direction: column; align-items: center; justify-content: center; width: 140px; min-height: 140px; padding: 1rem; background: #f8fbff; border: 1px solid rgba(13, 110, 253, 0.12); border-radius: 24px; transition: transform 0.35s ease, box-shadow 0.35s ease; opacity: 0; animation: fadeInUp 0.8s ease forwards; }
        .flow-step:nth-child(1) { animation-delay: 0.1s; }
        .flow-step:nth-child(2) { animation-delay: 0.3s; }
        .flow-step:nth-child(3) { animation-delay: 0.5s; }
        .flow-step:nth-child(4) { animation-delay: 0.7s; }
        .flow-step:nth-child(5) { animation-delay: 0.9s; }
        .flow-step:hover { transform: translateY(-6px); box-shadow: 0 18px 32px rgba(13, 110, 253, 0.15); }
        .flow-icon { width: 60px; height: 60px; display: grid; place-items: center; border-radius: 50%; background: rgba(13, 110, 253, 0.1); margin-bottom: 0.8rem; }
        .flow-icon i { font-size: 1.75rem; color: #0d6efd; }
        .flow-step p { margin: 0; font-weight: 700; color: #1f2937; font-size: 0.98rem; text-align: center; }
        .flow-arrow { font-size: 1.4rem; color: #6b7280; margin: 0 0.35rem; opacity: 0; animation: fadeIn 0.8s ease-in forwards; }
        .flow-arrow:nth-of-type(1) { animation-delay: 0.25s; }
        .flow-arrow:nth-of-type(2) { animation-delay: 0.45s; }
        .flow-arrow:nth-of-type(3) { animation-delay: 0.65s; }
        .flow-arrow:nth-of-type(4) { animation-delay: 0.85s; }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(16px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">Queue System Guide</a>
        <div>
            <a class="btn btn-outline-light me-2" href="index.php">Kiosk</a>
            <a class="btn btn-outline-light me-2" href="staff.php">Staff</a>
            <a class="btn btn-outline-light" href="monitor.php">Monitor</a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="text-center mb-5">
        <h1 class="display-4 animate__animated animate__fadeIn">How the Queue System Works</h1>
        <p class="lead animate__animated animate__fadeIn animate__delay-1s">A step-by-step guide to the queue simulation process</p>
    </div>

    <!-- Animated Flow Visualization -->
    <div class="animation-container">
        <div class="flow-step">
            <div class="flow-icon"><i class="fas fa-user-plus"></i></div>
            <p>Student Joins</p>
        </div>
        <div class="flow-arrow"><i class="fas fa-arrow-right"></i></div>
        <div class="flow-step">
            <div class="flow-icon"><i class="fas fa-user-cog"></i></div>
            <p>Staff Calls</p>
        </div>
        <div class="flow-arrow"><i class="fas fa-arrow-right"></i></div>
        <div class="flow-step">
            <div class="flow-icon"><i class="fas fa-tv"></i></div>
            <p>Monitor Shows</p>
        </div>
        <div class="flow-arrow"><i class="fas fa-arrow-right"></i></div>
        <div class="flow-step">
            <div class="flow-icon"><i class="fas fa-check-circle"></i></div>
            <p>Service Done</p>
        </div>
        <div class="flow-arrow"><i class="fas fa-arrow-right"></i></div>
        <div class="flow-step">
            <div class="flow-icon"><i class="fas fa-chart-line"></i></div>
            <p>Analytics</p>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <!-- Step 1 -->
            <div class="card step-card shadow-sm animate-flow">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center">
                        <div class="step-number me-3">1</div>
                        <div>
                            <h5 class="card-title">Student Arrives at Kiosk</h5>
                            <p class="card-text">The student clicks "Get Queue Number" on the kiosk page to receive a unique ticket number and join the queue.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flow-arrow animate__animated animate__fadeIn animate__delay-2s">↓</div>

            <!-- Step 2 -->
            <div class="card step-card shadow-sm animate-flow">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center">
                        <div class="step-number me-3">2</div>
                        <div>
                            <h5 class="card-title">Staff Calls Next Customer</h5>
                            <p class="card-text">Staff member clicks "Call Next" on the staff dashboard to serve the next waiting customer. Only one customer can be served at a time.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flow-arrow animate__animated animate__fadeIn animate__delay-3s">↓</div>

            <!-- Step 3 -->
            <div class="card step-card shadow-sm animate-flow">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center">
                        <div class="step-number me-3">3</div>
                        <div>
                            <h5 class="card-title">Monitor Displays Current Status</h5>
                            <p class="card-text">The public monitor shows the currently serving ticket number and the next few in line, updating in real-time.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flow-arrow animate__animated animate__fadeIn animate__delay-4s">↓</div>

            <!-- Step 4 -->
            <div class="card step-card shadow-sm animate-flow">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center">
                        <div class="step-number me-3">4</div>
                        <div>
                            <h5 class="card-title">Service Completes</h5>
                            <p class="card-text">When service is done, staff clicks "Finish" to mark the ticket as completed and automatically call the next customer.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flow-arrow animate__animated animate__fadeIn animate__delay-5s">↓</div>

            <!-- Step 5 -->
            <div class="card step-card shadow-sm animate-flow">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center">
                        <div class="step-number me-3">5</div>
                        <div>
                            <h5 class="card-title">Analytics & Reporting</h5>
                            <p class="card-text">Staff can view analytics for wait times, service durations, daily volumes, and peak hours to optimize operations.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="text-center mt-5">
        <p class="text-muted">This simulation demonstrates a typical queue management system with real-time updates and automated workflows.</p>
        <a href="index.php" class="btn btn-primary btn-lg">Try It Out</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>