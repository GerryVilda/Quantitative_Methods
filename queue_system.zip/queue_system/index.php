<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Student Queue Kiosk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-..." crossorigin="anonymous">
    <style>
        html, body { min-height: 100%; height: 100%; }
        body { background: linear-gradient(135deg, #1d7bcf 0%, #1068ba 45%, #0f5090 100%); color: #fff; display: flex; flex-direction: column; }
        .glass { background: rgba(255, 255, 255, .14); backdrop-filter: blur(12px); border: 1px solid rgba(255,255,255,.25); }
        .btn-brand { background: #ffc107; color: #1d1d1d; font-weight: 700; font-size: 1.5rem; padding: 1rem 2.5rem; }
        .btn-brand:hover { background: #f0ad4e; }
        .hero-card { min-height: calc(100vh - 160px); display: flex; align-items: center; justify-content: center; }
        .hero-card .card-body { padding: 3rem; }
        .hero-title { font-size: clamp(3rem, 5vw, 5rem); line-height: 1; }
        .hero-text { font-size: clamp(1rem, 2vw, 1.6rem); }
        .status-box { font-size: 1.3rem; }
        .live-panel h4 { font-size: 1.8rem; }
        .live-panel p { font-size: 1.2rem; }
        @media (max-width: 768px) {
            .btn-brand { font-size: 1.2rem; padding: 0.9rem 1.8rem; }
            .hero-card .card-body { padding: 2rem; }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark bg-opacity-60 shadow-sm mb-4">
        <div class="container d-flex justify-content-between align-items-center">
            <a class="navbar-brand" href="#">Queue System</a>
            <div>
                <a class="btn btn-outline-light btn-sm me-2" href="how_it_works.php">How It Works</a>
                <a class="btn btn-outline-light btn-sm me-2" href="monitor.php">Live Monitor</a>
                <span class="badge bg-warning text-dark">Student Kiosk</span>
            </div>
        </div>
    </nav>

    <div class="container flex-grow-1">
        <div class="row justify-content-center align-items-center h-100 gx-4">
            <div class="col-xl-8 col-lg-9 col-md-10">
                <div class="card glass shadow-lg hero-card h-100">
                    <div class="card-body text-center d-flex flex-column justify-content-center">
                        <div>
                            <h1 class="fw-bold hero-title">Get Your Ticket</h1>
                            <p class="mb-4 hero-text">Fast, safe and fair. Your token is generated instantly.</p>
                        </div>

                        <button id="btnQueue" class="btn btn-brand mb-4" onclick="getQueue()">Get Queue Number</button>

                        <p id="status" class="mt-4 mx-3 mb-0 py-3 rounded status-box"></p>
                        <p class="text-white-75 mt-3">Your number will be called on the live monitor when it is your turn.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="text-center mt-4 text-white-50">
        &copy; 2026 Queue System • Built for efficient student service
    </footer>

<script>
async function getQueue(){
    const btn = document.getElementById('btnQueue');
    btn.disabled = true;
    const response = await fetch('generate_queue.php');
    const ticket = await response.text();

    const status = document.getElementById('status');
    status.className = 'mt-4 mx-5 py-3 rounded alert alert-success';
    status.innerText = `Your Queue Number: ${ticket}`;

    btn.disabled = false;
    loadPreview();
}

function formatDuration(seconds) {
    if (!seconds) return 'n/a';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return mins ? `${mins}m ${secs}s` : `${secs}s`;
}
</script>
</body>
</html>