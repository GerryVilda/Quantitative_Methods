<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Staff | Queue Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <style>
        body { background: #f4f7fb; }
        .card-solid { border: 0; border-radius: 14px; box-shadow: 0 8px 24px rgba(0,0,0,0.08); }
        .btn-primary-cust { background: #1d7bcf; border: 0; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container d-flex justify-content-between align-items-center">
        <a class="navbar-brand" href="#">Queue System - Staff</a>
        <div class="d-flex gap-2">
            <a class="btn btn-outline-light btn-sm" href="how_it_works.php">How It Works</a>
            <a class="btn btn-outline-light btn-sm" href="index.php">Kiosk</a>
            <a class="btn btn-outline-light btn-sm" href="monitor.php">Monitor</a>
            <a class="btn btn-outline-secondary btn-sm" href="analytics.php">Analytics</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="row g-3">
        <div class="col-lg-8">
            <div class="card card-solid p-3">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h3 class="mb-0">Now Serving</h3>
                        <p class="text-muted">Most current active ticket</p>
                    </div>
                    <div class="display-1 text-primary" id="nowServing">---</div>
                </div>

                <div class="mb-3 d-flex gap-2">
                    <button id="btnCallNext" class="btn btn-success" onclick="callNext()">Call Next</button>
                    <button id="btnFinish" class="btn btn-danger" onclick="finish()">Finish</button>
                </div>

                <h5>Up Next</h5>
                <ul id="nextQueue" class="list-group list-group-flush"></ul>
                <div class="row g-3 mt-4">
                    <div class="col-md-6">
                        <div class="p-3 bg-white rounded-4 border">
                            <h6 class="text-muted">Current Ticket Details</h6>
                            <p class="mb-1">Arrival: <strong id="currentArrival">-</strong></p>
                            <p class="mb-0">Serving Since: <strong id="currentStarted">-</strong></p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="p-3 bg-white rounded-4 border">
                            <h6 class="text-muted">Recently Completed</h6>
                            <ul id="recentCompleted" class="list-unstyled mb-0"></ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card card-solid p-3">
                <h5 class="fw-bold mb-3">Queue Metrics</h5>
                <div id="metrics" class="fs-6">Loading...</div>
                <hr>
                <div class="mb-3">
                    <div class="row text-center">
                        <div class="col-6 border-end">
                            <div class="fs-1 fw-bold text-primary" id="waitingCount">-</div>
                            <div class="text-muted">Waiting</div>
                        </div>
                        <div class="col-6">
                            <div class="fs-1 fw-bold text-success" id="servingCount">-</div>
                            <div class="text-muted">Serving</div>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <p class="mb-1"><strong>Done Today:</strong> <span id="doneToday">-</span></p>
                    <p class="mb-0"><strong>Avg Service:</strong> <span id="avgService">-</span></p>
                </div>
                <p id="staffNotice" class="text-danger mb-3"></p>
                <hr>
                <div class="d-grid gap-2">
                    <button class="btn btn-primary-cust btn-lg" onclick="refreshData()">Refresh Now</button>
                    <a class="btn btn-outline-secondary" href="analytics.php">Open Analytics</a>
                </div>
                <p class="text-muted mt-3 mb-0" id="lastRefresh">Last updated: -</p>
            </div>
        </div>
    </div>
</div>

<script>
function formatDuration(seconds) {
    if (!seconds) return '-';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return mins ? `${mins}m ${secs}s` : `${secs}s`;
}

async function refreshData(){
    const res = await fetch('display_queue.php');
    const data = await res.json();

    document.getElementById('nowServing').innerText = data.serving || '---';

    const nextQueue = document.getElementById('nextQueue');
    nextQueue.innerHTML = '';
    if(!data.next.length){
        nextQueue.innerHTML = '<li class="list-group-item">No waiting tickets</li>';
    } else {
        data.next.forEach(item => {
            nextQueue.innerHTML += `<li class="list-group-item">${item.queue_number}</li>`;
        });
    }

    document.getElementById('waitingCount').innerText = data.waiting;
    document.getElementById('servingCount').innerText = data.serving_count;
    document.getElementById('doneToday').innerText = data.done_today;
    document.getElementById('avgService').innerText = data.avg_service_seconds ? formatDuration(data.avg_service_seconds) : 'n/a';

    const metrics = document.getElementById('metrics');
    metrics.innerHTML = `<strong>Current Ticket:</strong> ${data.serving || '---'}<br><strong>Next Up:</strong> ${data.next.length ? data.next[0].queue_number : 'None'}`;
    document.getElementById('currentArrival').innerText = data.serving_arrival || '-';
    document.getElementById('currentStarted').innerText = data.serving_started || '-';

    const recentCompleted = document.getElementById('recentCompleted');
    recentCompleted.innerHTML = '';
    if (!data.recent_done.length) {
        recentCompleted.innerHTML = '<li class="text-muted">No completed tickets yet.</li>';
    } else {
        data.recent_done.forEach(item => {
            recentCompleted.innerHTML += `<li class="mb-2"><strong>${item.queue_number}</strong> • ${formatDuration(item.duration_seconds)}</li>`;
        });
    }

    const staffNotice = document.getElementById('staffNotice');
    const btnCallNext = document.getElementById('btnCallNext');
    if (data.serving_count > 0) {
        btnCallNext.disabled = true;
        staffNotice.innerText = 'Finish the active ticket before calling the next one.';
    } else {
        btnCallNext.disabled = false;
        staffNotice.innerText = '';
    }

    document.getElementById('lastRefresh').innerText = `Last updated: ${new Date().toLocaleTimeString()}`;
}

async function callNext(){
    const res = await fetch('call_next.php');
    const text = await res.text();
    const staffNotice = document.getElementById('staffNotice');

    if (text === 'ALREADY_SERVING') {
        staffNotice.innerText = 'There is already a ticket being served. Finish it before calling the next one.';
    } else if (text === 'NO_TICKET') {
        staffNotice.innerText = 'No waiting tickets are available right now.';
    } else {
        staffNotice.innerText = `Now serving ticket ${text}.`;
    }

    await refreshData();
}

async function finish(){
    await fetch('finish.php');
    await refreshData();
}

refreshData();
setInterval(refreshData, 2500);
</script>
</body>
</html>