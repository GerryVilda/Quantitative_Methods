@echo off
REM Quick startup script for the queue system
REM 1) Ensure XAMPP Apache and MySQL are running or uncomment built-in PHP server path
REM 2) Open browser to app pages

REM If using XAMPP, just open the URLs below manually or via this script:
start "" "http://localhost/queue_system/index.php"
start "" "http://localhost/queue_system/staff.php"
start "" "http://localhost/queue_system/monitor.php"
start "" "http://localhost/queue_system/analytics.php"

echo Opened app pages in browser.

echo If you prefer built-in PHP server, run:
REM php -S localhost:8080 -t "%~dp0"

pause