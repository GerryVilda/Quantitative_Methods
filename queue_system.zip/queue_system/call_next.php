<?php
include "db.php";

// Prevent calling next when a ticket is already being served.
$servingRes = $conn->query("SELECT queue_number FROM queue WHERE status='serving' LIMIT 1");
if ($servingRes->fetch_assoc()) {
    echo "ALREADY_SERVING";
    exit;
}

$result = $conn->query("SELECT * FROM queue WHERE status='waiting' ORDER BY id ASC LIMIT 1");
if ($row = $result->fetch_assoc()) {
    $id = $row['id'];
    $queue = $row['queue_number'];
    $conn->query("UPDATE queue SET status='serving', service_start=NOW() WHERE id=$id");
    echo $queue;
    exit;
}

echo "NO_TICKET";
?>