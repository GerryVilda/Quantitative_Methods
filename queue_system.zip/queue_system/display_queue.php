<?php
include "db.php";

$data = [];

// now serving
$res1 = $conn->query("SELECT queue_number, arrival_time, service_start FROM queue WHERE status='serving' LIMIT 1");
if ($row1 = $res1->fetch_assoc()) {
    $data['serving'] = $row1['queue_number'];
    $data['serving_arrival'] = $row1['arrival_time'];
    $data['serving_started'] = $row1['service_start'];
    $data['serving_elapsed'] = $row1['service_start'] ? (int)(time() - strtotime($row1['service_start'])) : 0;
} else {
    $data['serving'] = "---";
    $data['serving_arrival'] = null;
    $data['serving_started'] = null;
    $data['serving_elapsed'] = 0;
}

// next 5
$res2 = $conn->query("SELECT queue_number, arrival_time FROM queue WHERE status='waiting' ORDER BY id ASC LIMIT 5");

$next = [];
while($row = $res2->fetch_assoc()){
    $next[] = [
        'queue_number' => $row['queue_number'],
        'arrival_time' => $row['arrival_time'],
    ];
}

$data['next'] = $next;

// counts
$resWaiting = $conn->query("SELECT COUNT(*) AS cnt FROM queue WHERE status='waiting'");
$data['waiting'] = $resWaiting->fetch_assoc()['cnt'] ?? 0;
$resServing = $conn->query("SELECT COUNT(*) AS cnt FROM queue WHERE status='serving'");
$data['serving_count'] = $resServing->fetch_assoc()['cnt'] ?? 0;
$resDoneToday = $conn->query("SELECT COUNT(*) AS cnt FROM queue WHERE status='done' AND DATE(service_end)=CURDATE()");
$data['done_today'] = $resDoneToday->fetch_assoc()['cnt'] ?? 0;

// average service duration
$resAvg = $conn->query("SELECT AVG(TIMESTAMPDIFF(SECOND, service_start, service_end)) AS avg_sec FROM queue WHERE status='done' AND service_start IS NOT NULL AND service_end IS NOT NULL");
$avgRow = $resAvg->fetch_assoc();
$data['avg_service_seconds'] = $avgRow && $avgRow['avg_sec'] ? (int)$avgRow['avg_sec'] : 0;

// longest waiting time
$resOldest = $conn->query("SELECT TIMESTAMPDIFF(MINUTE, arrival_time, NOW()) AS minutes FROM queue WHERE status='waiting' ORDER BY arrival_time ASC LIMIT 1");
$oldestRow = $resOldest->fetch_assoc();
$data['longest_wait_minutes'] = $oldestRow && $oldestRow['minutes'] ? (int)$oldestRow['minutes'] : 0;

// recent completed tickets
$resRecent = $conn->query("SELECT queue_number, service_start, service_end, TIMESTAMPDIFF(SECOND, service_start, service_end) AS duration_sec FROM queue WHERE status='done' ORDER BY service_end DESC LIMIT 5");
$recentDone = [];
while ($row = $resRecent->fetch_assoc()) {
    $recentDone[] = [
        'queue_number' => $row['queue_number'],
        'completed_at' => $row['service_end'],
        'duration_seconds' => (int)$row['duration_sec'],
    ];
}
$data['recent_done'] = $recentDone;

echo json_encode($data);
?>