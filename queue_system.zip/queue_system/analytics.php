<?php
include "db.php";

$from = isset($_GET['from']) ? date('Y-m-d', strtotime($_GET['from'])) : date('Y-m-d');
$to = isset($_GET['to']) ? date('Y-m-d', strtotime($_GET['to'])) : date('Y-m-d');
$toEnd = date('Y-m-d', strtotime($to . ' +1 day'));

$totRes = $conn->query("SELECT COUNT(*) as total FROM queue WHERE arrival_time >= '$from' AND arrival_time < '$toEnd'");
$tot = $totRes->fetch_assoc();
$doneRes = $conn->query("SELECT COUNT(*) as done FROM queue WHERE status='done' AND service_end >= '$from' AND service_end < '$toEnd'");
$done = $doneRes->fetch_assoc();
$pendingRes = $conn->query("SELECT COUNT(*) as pending FROM queue WHERE status IN ('waiting','serving') AND arrival_time >= '$from' AND arrival_time < '$toEnd'");
$pending = $pendingRes->fetch_assoc();
$avgWaitRes = $conn->query("SELECT AVG(TIMESTAMPDIFF(SECOND, arrival_time, service_start)) as avg_wait FROM queue WHERE service_start IS NOT NULL AND service_start >= '$from' AND service_start < '$toEnd'");
$avgWait = $avgWaitRes->fetch_assoc();
$avgServiceRes = $conn->query("SELECT AVG(TIMESTAMPDIFF(SECOND, service_start, service_end)) as avg_service FROM queue WHERE status='done' AND service_end >= '$from' AND service_end < '$toEnd'");
$avgService = $avgServiceRes->fetch_assoc();
$peakRes = $conn->query("SELECT HOUR(service_end) as hour, COUNT(*) as cnt FROM queue WHERE status='done' AND service_end >= '$from' AND service_end < '$toEnd' GROUP BY hour ORDER BY cnt DESC LIMIT 1");
$peakHourRow = $peakRes->fetch_assoc();
$peakHour = $peakHourRow ? sprintf('%02d:00', $peakHourRow['hour']) : 'N/A';
$statusRes = $conn->query("SELECT status, COUNT(*) as cnt FROM queue WHERE arrival_time >= '$from' AND arrival_time < '$toEnd' GROUP BY status");
$statusCounts = ['waiting' => 0, 'serving' => 0, 'done' => 0];
while ($row = $statusRes->fetch_assoc()) {
    $statusCounts[$row['status']] = (int)$row['cnt'];
}

$wait_samples = [];
$waitRes = $conn->query("SELECT queue_number, TIMESTAMPDIFF(SECOND, arrival_time, service_start) AS wait_seconds FROM queue WHERE service_start IS NOT NULL AND arrival_time >= '$from' AND arrival_time < '$toEnd' ORDER BY service_end DESC LIMIT 10");
while ($row = $waitRes->fetch_assoc()) {
    $wait_samples[] = [
        'label' => '#' . $row['queue_number'],
        'value' => (int)$row['wait_seconds'],
    ];
}
$waitLabels = array_column($wait_samples, 'label');
$waitValues = array_column($wait_samples, 'value');

$days = [];
$period = new DatePeriod(new DateTime($from), new DateInterval('P1D'), (new DateTime($to))->modify('+1 day'));
foreach ($period as $date) {
    $days[$date->format('Y-m-d')] = 0;
}
$dayRes = $conn->query("SELECT DATE(arrival_time) as day, COUNT(*) as cnt FROM queue WHERE arrival_time >= '$from' AND arrival_time < '$toEnd' GROUP BY DATE(arrival_time)");
while ($row = $dayRes->fetch_assoc()) {
    $days[$row['day']] = (int)$row['cnt'];
}
$dailyLabels = array_keys($days);
$dailyValues = array_values($days);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Analytics</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <style>
        body { background: #eef2f8; }
        .stat-card { border-left: 5px solid #0d6efd; }
        .metric-label { color: #65737e; text-transform: uppercase; font-size: .8rem; }
        .metric-value { font-size: 2.35rem; font-weight: 700; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">Queue Analytics</a>
        <a class="btn btn-outline-light" href="staff.php">Back to Staff</a>
    </div>
</nav>

<div class="container py-4">
    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <form class="row g-3 align-items-end" method="get">
                <div class="col-md-4">
                    <label class="form-label">From</label>
                    <input type="date" name="from" value="<?php echo htmlspecialchars($from) ?>" class="form-control" />
                </div>
                <div class="col-md-4">
                    <label class="form-label">To</label>
                    <input type="date" name="to" value="<?php echo htmlspecialchars($to) ?>" class="form-control" />
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary w-100">Apply Date Range</button>
                </div>
            </form>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-4 col-md-6">
            <div class="card stat-card shadow-sm p-3">
                <div class="metric-label">Total Tickets</div>
                <div class="metric-value"><?php echo (int)$tot['total'] ?></div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="card stat-card shadow-sm p-3">
                <div class="metric-label">Completed</div>
                <div class="metric-value"><?php echo (int)$done['done'] ?></div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="card stat-card shadow-sm p-3">
                <div class="metric-label">Pending</div>
                <div class="metric-value"><?php echo (int)$pending['pending'] ?></div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="card stat-card shadow-sm p-3">
                <div class="metric-label">Average Wait</div>
                <div class="metric-value"><?php echo round($avgWait['avg_wait'] ?? 0, 1) ?>s</div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="card stat-card shadow-sm p-3">
                <div class="metric-label">Average Service</div>
                <div class="metric-value"><?php echo round($avgService['avg_service'] ?? 0, 1) ?>s</div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="card stat-card shadow-sm p-3">
                <div class="metric-label">Peak Hour</div>
                <div class="metric-value"><?php echo $peakHour ?></div>
            </div>
        </div>
    </div>

    <div class="row gy-4 mt-3">
        <div class="col-lg-7">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h4 class="mb-3">Daily Ticket Volume</h4>
                    <canvas id="dailyChart" height="180"></canvas>
                </div>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h4 class="mb-3">Recent Wait Times</h4>
                    <canvas id="waitChart" height="180"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const dailyLabels = <?php echo json_encode($dailyLabels); ?>;
const dailyData = <?php echo json_encode($dailyValues); ?>;
const waitLabels = <?php echo json_encode($waitLabels); ?>;
const waitData = <?php echo json_encode($waitValues); ?>;

new Chart(document.getElementById('dailyChart'), {
    type: 'line',
    data: {
        labels: dailyLabels,
        datasets: [{
            label: 'Tickets per day',
            data: dailyData,
            borderColor: 'rgba(13, 110, 253, 1)',
            backgroundColor: 'rgba(13, 110, 253, 0.15)',
            fill: true,
            tension: 0.3,
            pointRadius: 4
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Tickets' }
            }
        },
        plugins: {
            legend: { display: false }
        }
    }
});

new Chart(document.getElementById('waitChart'), {
    type: 'line',
    data: {
        labels: waitLabels,
        datasets: [{
            label: 'Wait time (sec)',
            data: waitData,
            borderColor: 'rgba(13, 110, 253, 1)',
            backgroundColor: 'rgba(13, 110, 253, 0.25)',
            fill: true,
            tension: 0.3,
            pointRadius: 4,
            pointBackgroundColor: 'rgba(13, 110, 253, 1)'
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Seconds' }
            }
        },
        plugins: {
            legend: { display: false }
        }
    }
});
</script>
</body>
</html>