<?php
include "db.php";

$conn->query("UPDATE queue 
SET status='done', service_end=NOW() 
WHERE status='serving'");
?>